<?php
include '../DBConnection.php';

// Get filter parameters
$selected_month = isset($_GET['month']) ? intval($_GET['month']) : date('n');
$selected_year = isset($_GET['year']) ? intval($_GET['year']) : date('Y');

// delete
if (isset($_GET['project_id']) && $_GET['confirm'] == 'yes') {
    // Get the user ID from the query string
    $project_id = intval($_GET['project_id']);

    // Prepare and execute the deletion query for 'users' table
    $deleteUserSql = "DELETE FROM project WHERE project_id = ?";
    $stmtUser = $connection->prepare($deleteUserSql);
    $stmtUser->bind_param("i", $project_id);

    // Execute both deletion queries
    if ($stmtUser->execute()) {
        // Redirect to the manage members page after successful deletion
        header('Location: o1_rapidRO12.php');
        exit();
    } else {
        // Handle error if either query fails
        echo "Error deleting user: " . $connection->error;
    }
} else {
    // Handle invalid request
    echo "Invalid request.";
}

//Add users
if (isset($_POST['submit'])) {
    // Generate a new project_id
    $project_id_query = "SELECT MAX(project_id) as max_id FROM project";
    $project_id_result = mysqli_query($connection, $project_id_query);
    $project_id_row = mysqli_fetch_assoc($project_id_result);
    $project_id = ($project_id_row['max_id'] ?? 0) + 1;  
    $oopap_id = $_POST['oopap_id'];
    $account_id = $_POST['account_id'];
    $allotment = $_POST['allotment'];
    $balances = $_POST['balances'];
    $created_at = $_POST['year']; // Use the selected date from the form

    // Validate required fields
    if (empty($account_id) || empty($allotment)) {
        $error_message = "Please fill in all required fields";
    } else {
        $sql = "INSERT INTO project (project_id, oopap_id, account_id, allotment, balances, created_at) VALUES (?, ?, ?, ?, ?, ?)";
        $stmt = $connection->prepare($sql);
        $stmt->bind_param("iiisss", $project_id, $oopap_id, $account_id, $allotment, $balances, $created_at);

        if ($stmt->execute()) {
            header('Location: o1_rapidRO12.php');
            exit();
        } else {
            $error_message = "Error saving data: " . $stmt->error;
        }
    }
}

// retrieve - Filter by year only for display
$select = mysqli_query(
    $connection,
    "SELECT project.*,
            account_title.account_title,
            account_title.account_code 
            FROM project
            LEFT JOIN account_title ON project.account_id = account_title.account_id
            WHERE oopap_id = 14
            AND YEAR(project.created_at) = $selected_year
            ORDER BY account_title.account_title ASC"
);

// Get oopap information    
$oopap_query = "SELECT description FROM oopap WHERE oopap_id = 14";
$oopap_result = mysqli_query($connection, $oopap_query);
$oopap_data = mysqli_fetch_assoc($oopap_result);
$description = $oopap_data['description'];

// account name
$query_account = "SELECT account_id, account_title, account_code FROM account_title ORDER BY account_title ASC";
$result_account = $connection->query($query_account);

// Fetch total allotment for the selected year
$total_allotment_query = "SELECT SUM(allotment) AS total_allotment FROM project WHERE oopap_id = 14 AND YEAR(created_at) = $selected_year";
$total_allotment_result = mysqli_query($connection, $total_allotment_query);
$total_allotment = mysqli_fetch_assoc($total_allotment_result)['total_allotment'];

// Calculate balances based on allotment and ORS total_amount for the selected month
$update_balances_query = "UPDATE project p 
                         SET p.balances = p.balances - (
                             SELECT COALESCE(SUM(ors.total_amount), 0) 
                             FROM obligation_history oh 
                             JOIN ors ON oh.ors_id = ors.ors_id 
                             WHERE oh.project_id = p.project_id
                             AND MONTH(ors.date) = $selected_month
                             AND YEAR(ors.date) = $selected_year
                         )
                         WHERE p.oopap_id = 14 
                         AND YEAR(p.created_at) = $selected_year";
mysqli_query($connection, $update_balances_query);

// Fetch total balances for the selected month and year
$total_balances_query = "SELECT SUM(balances) AS total_balances FROM project WHERE oopap_id = 14 AND YEAR(created_at) = $selected_year";
$total_balances_result = mysqli_query($connection, $total_balances_query);
$total_balances = mysqli_fetch_assoc($total_balances_result)['total_balances'];
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">

    <title>Dashboard - NiceAdmin Bootstrap Template</title>
    <meta content="" name="description">
    <meta content="" name="keywords">

    <!-- Favicons -->
    <link href="../NiceAdmin/assets/img/favicon.png" rel="icon">
    <link href="../NiceAdmin/assets/img/apple-touch-icon.png" rel="apple-touch-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.gstatic.com" rel="preconnect">
    <link
        href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i"
        rel="stylesheet">

    <!-- Vendor CSS Files -->
    <link href="../NiceAdmin/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="../NiceAdmin/assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
    <link href="../NiceAdmin/assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
    <link href="../NiceAdmin/assets/vendor/quill/quill.snow.css" rel="stylesheet">
    <link href="../NiceAdmin/assets/vendor/quill/quill.bubble.css" rel="stylesheet">
    <link href="../NiceAdmin/assets/vendor/remixicon/remixicon.css" rel="stylesheet">
    <link href="../NiceAdmin/assets/vendor/simple-datatables/style.css" rel="stylesheet">

    <!-- Template Main CSS File -->
    <link href="../NiceAdmin/assets/css/style.css" rel="stylesheet">
</head>

<body>

    <?php include "Includes/header.php"; ?>
    <?php include "Includes/sidebar.php"; ?>

    <main id="main" class="main">

        <div class="pagetitle">
            <h1>OO1 - <?php echo htmlspecialchars($description); ?></h1>
        </div><!-- End Page Title -->

        <section class="section dashboard">
            <!-- Filter Form -->
            <div class="card mb-3">
                <div class="card-body">
                    <h5 class="card-title">Filter by Month and Year</h5>
                    <form method="get" action="o1_rapidRO12.php" class="row g-3">
                        <div class="col-md-4">
                            <label for="year" class="form-label">Year</label>
                            <select class="form-select" id="year" name="year">
                                <?php
                                $current_year = date('Y');
                                for ($year = $current_year; $year >= $current_year - 5; $year--) {
                                    $selected = ($year == $selected_year) ? 'selected' : '';
                                    echo "<option value=\"$year\" $selected>$year</option>";
                                }
                                ?>
                            </select>
                            <small class="text-muted">Shows total allotment for the selected year</small>
                        </div>
                        <div class="col-md-4">
                            <label for="month" class="form-label">Month (Remaining Balances)</label>
                            <select class="form-select" id="month" name="month">
                                <?php
                                $months = [
                                    1 => 'January', 2 => 'February', 3 => 'March', 4 => 'April',
                                    5 => 'May', 6 => 'June', 7 => 'July', 8 => 'August',
                                    9 => 'September', 10 => 'October', 11 => 'November', 12 => 'December'
                                ];
                                foreach ($months as $num => $name) {
                                    $selected = ($num == $selected_month) ? 'selected' : '';
                                    echo "<option value=\"$num\" $selected>$name</option>";
                                }
                                ?>
                            </select>
                            <small class="text-muted">Shows remaining balances for the selected month</small>
                        </div>
                        
                        <div class="col-md-4 d-flex align-items-end">
                            <button type="submit" class="btn btn-primary">Apply Filter</button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Cards Row -->
            <div class="row">
                <!-- Total Allotment Card -->
                <div class="col-md-6">
                    <div class="card bg-white text-dark mb-3">
                        <div class="card-body">
                            <h5 class="card-title">Total Allotment (Year <?php echo $selected_year; ?>)</h5>
                            <h3 class="card-text">₱<?php echo number_format($total_allotment, 2); ?></h3>
                        </div>
                    </div>
                </div>
                <!-- Total Balances Card -->
                <div class="col-md-6">
                    <div class="card bg-white text-dark mb-3">
                        <div class="card-body">
                            <h5 class="card-title">Remaining Balances (<?php echo $months[$selected_month]; ?> <?php echo $selected_year; ?>)</h5>
                            <h3 class="card-text">₱<?php echo number_format($total_balances, 2); ?></h3>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card">
                <div class="card-body">
                    <?php if (isset($error_message)): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <?php echo $error_message; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                    <?php endif; ?>
                    <h5 class="card-title">
                        <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                            data-bs-target="#addUserModal">Add Project/Program/Activities</button>
                    </h5>
                    <p></p>

                    <!-- Modal for Add User Form -->
                    <div class="modal fade" id="addUserModal" tabindex="-1" aria-labelledby="addUserModalLabel"
                        aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="addUserModalLabel">Add Project/Program/Activities
                                    </h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                                        aria-label="Close"></button>
                                </div>
                                <div class="modal-body">
                                    <form method="post" id="addUserForm">
                                        <div class="mb-3">
                                            <input type="hidden" class="form-control" id="oopap_id" name="oopap_id"
                                                value="14" readonly required autocomplete="off">
                                        </div>
                                        <div class="mb-3">
                                            <label for="account_id" class="form-label">Account Title <span class="text-danger">*</span></label>
                                            <select class="form-control" name="account_id" id="account_id" required>
                                                <option value="">Select Account</option>
                                                <?php
                                                while ($row = $result_account->fetch_assoc()) {
                                                    echo "<option value='" . htmlspecialchars($row['account_id']) . "' 
                                        data-code='" . htmlspecialchars($row['account_code']) . "'>"
                                                        . htmlspecialchars($row['account_title']) . " - " . htmlspecialchars($row['account_code']) . ""
                                                        . "</option>";
                                                }
                                                ?>
                                            </select>
                                        </div>
                                        <div class="mb-3">
                                            <label for="allotment" class="form-label">Allotment</label>
                                            <input type="number" step="0.01" class="form-control" id="allotment" name="allotment"
                                                placeholder="Enter Allotment" required autocomplete="off"
                                                oninput="updateBalances()">
                                        </div>
                                        <div class="mb-3">
                                            <input type="hidden" class="form-control" id="balances" name="balances"
                                                placeholder="Balances" readonly>
                                        </div>

                                        <div class="form-group">
                                            <label for="year">Date and Year:</label>
                                            <input type="date" class="form-control" id="year" name="year" required value="<?php echo date('Y-m-d'); ?>">
                                        </div>
                                        <div class="modal-footer">
                                            <!-- <button type="button" class="btn btn-secondary"
                                        data-bs-dismiss="modal">Close</button> -->
                                            <button type="button" class="btn btn-secondary"
                                                onclick="clearForm()">Clear</button>
                                            <button type="submit" id="submit" name="submit"
                                                class="btn btn-primary">Save</button>
                                        </div>
                                    </form>
                                </div>

                            </div>
                        </div>
                    </div>

                    <!-- Table with stripped rows -->
                    <table class="table datatable">
                        <thead>
                            <tr>
                                <th>Project/Activities/Program</th>
                                <th>Code</th>
                                <th>Allotment</th>
                                <th>Balances</th>
                                <th>Date</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($row = mysqli_fetch_assoc($select)) { ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($row['account_title']); ?></td>
                                    <td><?php echo htmlspecialchars($row['account_code']); ?></td>
                                    <td><?php echo htmlspecialchars(number_format($row['allotment'], 2)); ?></td>
                                    <td><?php echo htmlspecialchars(number_format($row['balances'], 2)); ?></td>
                                    <td><?php echo date("F-d-Y", strtotime($row['created_at'])); ?></td>
                                    <td>
                                        <button type="button" class="btn btn-primary edit-btn" data-bs-toggle="modal"
                                            data-bs-target="#editModal" data-id="<?php echo $row['project_id']; ?>"
                                            data-account_id="<?php echo htmlspecialchars($row['account_id']); ?>"
                                            data-account_title="<?php echo htmlspecialchars($row['account_title']); ?>"
                                            data-allotment="<?php echo htmlspecialchars($row['allotment']); ?>">
                                            <i class="bi bi-pencil" data-bs-toggle="tooltip" data-bs-placement="top"
                                                title="Edit"></i>
                                        </button>

                                        <button type="button" class="btn btn-danger"
                                            onclick="deleteUser(<?php echo $row['project_id']; ?>)"><i class="bi bi-trash"
                                                data-bs-toggle="tooltip" data-bs-placement="top"
                                                title="Delete"></i></i></button>
                                    </td>
                                </tr>
                            <?php } ?>
                        </tbody>

                    </table>
                </div>
            </div>

        </section>

    </main><!-- End #main -->

    <!-- update modal -->
    <div class="modal fade" id="editModal" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editModalLabel">Edit Project/Program/Activities</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form method="post" id="editUserForm" action="update_o1_rapidRO12.php">
                        <input type="hidden" id="edit_project_id" name="project_id">
                        <input type="hidden" id="edit_account_id" name="edit_account_id">

                        <div class="mb-3">
                            <label for="edit_account_id" class="form-label">Project/Program/Activities</label>
                            <input type="text" class="form-control" id="edit_account_title" name="account_id" required
                                autocomplete="off" readonly>
                        </div>

                        <div class="mb-3">
                            <label for="edit_allotment" class="form-label">Allotment</label>
                            <input type="number" class="form-control" id="edit_allotment" name="allotment" step="0.01"
                                required autocomplete="off">
                        </div>

                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" id="update" name="update" class="btn btn-primary">Update</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>


    <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i
            class="bi bi-arrow-up-short"></i></a>

    <!-- Vendor JS Files -->
    <script src="../NiceAdmin/assets/vendor/apexcharts/apexcharts.min.js"></script>
    <script src="../NiceAdmin/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="../NiceAdmin/assets/vendor/chart.js/chart.umd.js"></script>
    <script src="../NiceAdmin/assets/vendor/echarts/echarts.min.js"></script>
    <script src="../NiceAdmin/assets/vendor/quill/quill.js"></script>
    <script src="../NiceAdmin/assets/vendor/simple-datatables/simple-datatables.js"></script>
    <script src="../NiceAdmin/assets/vendor/tinymce/tinymce.min.js"></script>
    <script src="../NiceAdmin/assets/vendor/php-email-form/validate.js"></script>

    <!-- Template Main JS File -->
    <script src="../NiceAdmin/assets/js/main.js"></script>

    <!-- clear -->
    <script>
        // Function to clear form
        function clearForm() {
            document.getElementById('addUserForm').reset();
        }
    </script>

    <!-- show update -->
    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const editButtons = document.querySelectorAll(".edit-btn");

            editButtons.forEach(button => {
                button.addEventListener("click", function () {
                    const id = this.getAttribute("data-id");
                    const account_id = this.getAttribute("data-account_id");
                    const account_title = this.getAttribute("data-account_title");
                    const allotment = this.getAttribute("data-allotment");

                    document.getElementById("edit_project_id").value = id;
                    document.getElementById("edit_account_id").value = account_id;
                    document.getElementById("edit_account_title").value = account_title;
                    document.getElementById("edit_allotment").value = allotment;
                });
            });
        });
    </script>

    <!-- delete -->
    <script>
        function deleteUser(rapidRO12ID) {
            if (confirm("Are you sure you want to delete this OO1-RAPID RO12?")) {
                window.location.href = 'o1_rapidRO12.php?project_id=' + rapidRO12ID + '&confirm=yes';
            }
        }
    </script>


    <script>
        document.addEventListener("DOMContentLoaded", function () {
            var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
            var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
                return new bootstrap.Tooltip(tooltipTriggerEl);
            });
        });

    </script>

    <!-- balances -->
    <script>
        function updateBalances() {
            var allotmentValue = document.getElementById('allotment').value;
            document.getElementById('balances').value = allotmentValue;
        }

        function clearForm() {
            document.getElementById("addUserForm").reset();
            updateBalances();
        }
    </script>

</body>

</html>